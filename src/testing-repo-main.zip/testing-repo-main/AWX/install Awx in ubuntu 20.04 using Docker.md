
# AWX Installation on ubuntu 20.04
`Ansible AWX `is a free and opensource front-end web application that provides a user interface to manage Ansible playbooks and inventories, as well as a REST API for Ansible. It is an open source version of Red Hat Ansible Tower. In this guide, we are going to install Ansible AWX on Ubuntu 20.04 LTS system. 
## Prerequisites
Before we get started, ensure that Ubuntu 20.04 system has the following:
•	8 GB of RAM
•	3.4 GHz CPU with 2 Cores
•	Hard disk space 20 GB
•	Internet Connection
## Table of Contents
*	[Step 1 Update package index](#Step-1-Update-package-index)
* [Step 2 Install docker-ce community edition](#Step-2-Install-docker-ce-community-edition)
*	[Step 3  Install docker-compose](#Step-3-Install-docker-compose)
*	[Step 4 Install Ansible](#Step-4-Install-Ansible)
*	[Step 5 Install node and NPM](#Step-5-Install-node-and-NPM) 
*	[Step 6 Install and Setup Ansible AWX](#Step-6-Install-and-Setup-Ansible-AWX)
*	[Step 7 Run the playbook file to Install AWX](#Step-7-Run-the-playbook-file-to-Install-AWX)
*	[Step 8 Access AWX Dashboard](#Step-8-Access-AWX-Dashboard)


Let’s jump into Ansible AWX installation steps
## Step 1 Update package index
Log in to your Ubuntu system and update the package lists as shown
```
$ sudo apt update
```
## Step 2 Install docker-ce community edition
Ansible AWX services will be deployed inside containers, and for that, we need to install docker and docker-compose to run multiple container images. There two main editions of `Docker – Enterprise Edition (EE) & Docker Community Edition (CE)`.
The Community Edition is freely available, and this is what we are going to use for our installation.
So, first, import the Docker repository GPG key as shown.
```
$ curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo apt-key add –
```
Next, add the Docker Community Edition (CE) repository as shown
```
$ sudo add-apt-repository "deb [arch=amd64] https://download.docker.com/linux/ubuntu\
 $(lsb_release -cs) stable"
```
Next, update the package lists and install Docker as shown:
```
$ sudo apt update
$ sudo apt install -y docker-ce docker-ce-cli containerd.io
```
Once installed, add your local or regular user to the docker group so that regular user can run docker commands without the need for invoking the sudo command.
Note:- replace the $USER with your user name
```
$ sudo usermod -aG docker $USER
```
Then restart the docker service.
```
$ sudo systemctl restart docker
```
Note: Do not forget to logout and login again, so that regular user can run docker commands without sudo.
Finally, you can confirm the docker version as shown
```
$ docker version
```

## Step 3  Install docker-compose
Next in line, we are going to install docker-compose. So, download the latest docker-compose
The following command will download the `1.29.2` release and save the executable file at `/usr/local/bin/docker-compose`, which will make this software globally accessible as `docker-compose`:
```
$ sudo curl -L "https://github.com/docker/compose/releases/download/1.29.2/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
```
Next, set the correct permissions so that the `docker-compose` command is executable:
```
$ sudo chmod +x /usr/local/bin/docker-compose
```
To verify that the installation was successful, you can run:
```
$ docker-compose –version
```
## Step 4 Install Ansible
Ansible is an open-source server automation and software provisioning tool that makes it possible to configure servers and deploy applications with ease. We are going to install Ansible which we shall later use to deploy AWX services.
Ansible is available on Ubuntu 20.04 repository, therefore use the APT command as shown.
```
$ sudo apt install -y ansible
```
Once the installation is completed, check the Ansible version as shown:
```
$ ansible --version
```
## Step 5 Install node and NPM 
Thereafter, install Node and NPM using the commands below
```
$ sudo apt install -y nodejs npm
$ sudo npm install npm –global
```
## Step 6 Install and Setup Ansible AWX
We are going to download the AWX installer from the Github repository. But let’s first install git, pip, and when (password generator)
```
$ sudo apt install -y python3-pip git pwgen
```
Next, install the docker-compose module that matches your version of docker-compose.
```
$ sudo pip3 install docker-compose==1.28.5
```
We are now going to download the latest AWX zip file from Github. To do so, we will use the wget command as follows.
```
$ wget https://github.com/ansible/awx/archive/17.1.0.zip
```

Once downloaded, unzip the file as shown.
```
$ sudo apt install unzip
$ unzip 17.1.0.zip
```
Once unzipped, be sure to locate the  awx-17.1.0 folder in your directory. Next, navigate into the installer directory inside the awx-17.1.0 folder.
```
$ cd awx-17.1.0/installer
```
Then generate a 30 character secret key using the pwgen tool as follows:
```
$ pwgen -N 1 -s 30
```

Copy this key and save it somewhere. Next, open the inventory file that is in the same directory.
```
$sudo vi inventory
```
Uncomment the admin and password parameters and be sure to provide a strong admin password. This is the password that you will use to log in to AWX on the web login page.
```
admin_user=admin
admin_password=<Strong-Admin-password>
```
Additionally, update the secret key variable with the secret key generated earlier.
```
secret_key=lKjpI3Hdj2PWlp8De6g2pDj9e5dU5e

Also you need to uncomment the below line for the Project Directory

project_data_dir=/var/lib/awx/projects
```

and save and exit from the file.
## Step 7 Run the playbook file to Install AWX
Lastly, we are going to run the Ansible playbook file called `install.yml` as shown.
```
$ ansible-playbook -i inventory install.yml
```
This only takes a few minutes to complete.

## Step 8 Access AWX Dashboard
To access the dashboard, launch your browser and browse the server’s IP as shown
```
http://server-ip-address
```
Provide your username and password and click on the ‘Log In’ button. This will usher you to the dashboard shown below.

And there you have it. We have successfully installed AWX on Ubuntu 20.04.
Refered Links :-
```
 https://www.linuxtechi.com/install-ansible-awx-on-ubuntu/
```
in above link instead of step 3 installing docker compose i have used step 1 in this link for installing docker compose` https://www.digitalocean.com/community/tutorials/how-to-install-and-use-docker-compose-on-ubuntu-20-04`
