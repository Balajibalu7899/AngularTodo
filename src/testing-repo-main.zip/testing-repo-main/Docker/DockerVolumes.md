
# Docker Volumes


Volumes Basically used to persist the file or data in the docker containers.

Say for Example we have one todo app that stores its data in a SQLite Database at `/etc/todos/todo.db` in the container’s filesystem. 
If you’re not familiar with SQLite, no worries! It’s simply a relational database in which all of the data is stored in a single file. 
While this isn’t the best for large-scale applications, it works for small demos.

With the database being a single file, if we can persist that file on the host and make it available to the next container, it should be able to pick up where the last one left off. By creating a volume and attaching (often called “mounting”) it to the directory the data is stored in, we can persist the data. As our container writes to the `todo.db` file, it will be persisted to the host in the volume.

As mentioned, we are going to use a named volume. Think of a named volume as simply a bucket of data. Docker maintains the physical location on the disk and you only need to remember the name of the volume. Every time you use the volume, Docker will make sure the correct data is provided.

There are two diffrent types of Docker Volumes
* [Named Volumes](#Named-Volumes)
* [Bind Mounts](#Bind-Mounts)

## Named Volumes
Named Volumes is like we need to create a volume using docker command and later we gonna use this volume to attach(mount) to the Docker Container.

To Explain this concept i will use a container called todo app

1) Create a volume by using the `docker volume create` command.

```
$ docker volume create todo-db
```
2) Attach this volume to the Docker container

Start the todo app container, but add the -v flag to specify a volume mount. We will use the named volume and mount it to `/etc/todos`, which will capture all files created at the path.

```

$ docker run -dp 3000:3000 -v todo-db:/etc/todos getting-started
```
In above command `-v` is used to attach the volume to the container , after `-v` we have `todo-db:/etc/todos` in this `todo-db` is the volume that we have created 
in step one we are attaching this volume to the `/etc/todos` location of the container , It means we are attaching this volume to the `/etc/todos` directory , what ever the file's that we create inside the container at `/etc/todos` directory will also mount to the `todo-db` volume.

A lot of people frequently ask “Where is Docker actually storing my data when I use a named volume?” If you want to know, you can use the `docker volume inspect` command.
```
docker volume inspect todo-db
[
    {
        "CreatedAt": "2019-09-26T02:18:36Z",
        "Driver": "local",
        "Labels": {},
        "Mountpoint": "/var/lib/docker/volumes/todo-db/_data",
        "Name": "todo-db",
        "Options": {},
        "Scope": "local"
    }
]
```
The `Mountpoint` is the actual location on the disk where the data is stored. Note that on most machines, you will need to have root access to access this directory from the host. But, that’s where it is!
`
## Accessing volume data directly on Docker Desktop
While running in Docker Desktop, the Docker commands are actually running inside a small VM on your machine. If you wanted to look at the actual contents of the Mountpoint directory, you would need to first get inside of the VM.
`
## Bind Mounts
In the previous Step, we talked about and used a named volume to persist the data in our database. Named volumes are great if we simply want to store data, as we don’t have to worry about where the data is stored.

With bind mounts, we control the exact mountpoint on the host. We can use this to persist data, but it’s often used to provide additional data into containers. When working on an application, we can use a bind mount to mount our source code into the container to let it see code changes, respond, and let us see the changes right away.

For Node-based applications, nodemon is a great tool to watch for file changes and then restart the application. There are equivalent tools in most other languages and frameworks.

### Quick volume type comparisons
Bind mounts and named volumes are the two main types of volumes that come with the Docker engine. However, additional volume drivers are available to support other use cases (`SFTP`, `Ceph`, `NetApp`, `S3`, and more).

<img width="472" alt="image" src="https://user-images.githubusercontent.com/100822553/210310006-173cd37f-469b-4e16-b5dd-8c3b7ce505b6.png">

While explaining Named volumes i have used the `getting-started` container , I will use same container to explain this concept as well.
### Make sure you don’t have any previous getting-started containers running.
### Run the following command from the app directory. We’ll explain what’s going on afterwards.

If you are using an x86-64 Mac or Linux device, then use the following command.
```
# docker run -dp 3000:3000 \
     -w /app -v "$(pwd):/app" \
     node:18-alpine \
     sh -c "yarn install && yarn run dev"
```
If you are using Windows, then use the following command in PowerShell.
```
PS c:> docker run -dp 3000:3000 `
     -w /app -v "$(pwd):/app" `
     node:18-alpine `
     sh -c "yarn install && yarn run dev"
```
In Above command instead of `$(pwd)` you can specify your own directory path 
Ex:-
```
# docker run -dp 3000:3000 \
     -w /app -v "/ubuntu/home/docker-tutorial:/app" \
     node:18-alpine \
     sh -c "yarn install && yarn run dev"
```
* `-dp 3000:3000` - same as before. Run in detached (background) mode and create a port mapping
* `-w /app` - sets the “working directory” or the current directory that the command will run from
* `-v "$(pwd):/app"` - bind mount the current directory from the host into the /app directory in the container
* `node:18-alpine` - the image to use. Note that this is the base image for our app.
* `sh -c "yarn install && yarn run dev"` - the command. We’re starting a shell using `sh` (alpine doesn’t have `bash`) and running `yarn install` to install all dependencies and then running `yarn run dev`. If we look in the `package.json`, we’ll see that the `dev` script is starting `nodemon`.

### You can watch the logs using docker logs. You’ll know you’re ready to go when you see this:
```
docker logs -f <container-id>
 nodemon src/index.js
 [nodemon] 2.0.20
 [nodemon] to restart at any time, enter `rs`
 [nodemon] watching dir(s): *.*
 [nodemon] starting `node src/index.js`
 Using sqlite database at /etc/todos/todo.db
 Listening on port 3000
```
## References
For more information about the volumes you can refer [here](https://docs.docker.com/get-started/05_persisting_data/)

