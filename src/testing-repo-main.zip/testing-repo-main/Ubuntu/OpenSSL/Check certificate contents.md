# Useful openssl commands to view certificate content

## Table of Contents

* [View the content of Private Key](#View-the-content-of-Private-Key)

* [View the content of CSR (Certificate Signing Request)](#View-the-content-of-CSR-Certificate-Signing-Request)

* [View the content of CA certificate](#View-the-content-of-CA-certificate)

* [View the content of signed Certificate](#View-the-content-of-signed-Certificate)

* [Conclusion](#Conclusion)

In this tutorial I will share openssl commands to view the content of different types of certificates such as

     * Certificate Signing Request (CSR)
     * Subject Alternative Name (SAN) certificate
     * server or client certificate
     * Certificate Authority (CA)
     
## View the content of Private Key

We generate a private key with `des3` encryption using following command which will prompt for passphrase:

```
~]# openssl genrsa -des3 -out ca.key 4096
```

To view the content of this private key we will use following `syntax`:

```
~]# openssl rsa -noout -text -in <PRIVATE_KEY>
```

So in our case the command would be:

```
~]# openssl rsa -noout -text -in ca.key
```
Sample output from my terminal (output is trimmed):

![image](https://user-images.githubusercontent.com/100822553/208467945-f81c39f8-c30e-4172-825b-46b8c379bfa4.png)


## View the content of CSR (Certificate Signing Request)

We can use the following command to generate a CSR using the key we created in the previous example:

```
~]# openssl req -new -key ca.key -out client.csr
```

Syntax to view the content of this CSR:

```
~]# openssl req -noout -text -in <CSR_FILE>
```
Sample output from my terminal:
![image](https://user-images.githubusercontent.com/100822553/208467853-d1427cd9-8476-41e2-8e90-e50fe9b7f93a.png)

## View the content of CA certificate

We can use our existing key to generate CA certificate, here `ca.cert.pem` is the CA certificate file:

```
 ~]# openssl req -new -x509 -days 365 -key ca.key -out ca.cert.pem
 ```
 To view the content of CA certificate we will use following syntax:
 
 ```
  ~]# openssl x509 -noout -text -in <CA_CERTIFICATE>
 ```
 Sample output from my terminal (output is trimmed):
 
 ![image](https://user-images.githubusercontent.com/100822553/208468277-03611c3d-2649-42c3-9669-c4b40db9e871.png)
 
 ## View the content of signed Certificate
 
 We can create a server or client certificate using following command using the key, CSR and CA certificate which we have created in this tutorial. Here server.crt is our final signed certificate
 
 ```
 ~]# openssl x509 -req -days 365 -in client.csr -CA ca.cert.pem -CAkey ca.key -CAcreateserial -out server.crt
 ```
 
 To view the content of similar certificate we can use following syntax:
 
 ```
 ~]# openssl x509 -noout -text -in <CERTIFICATE>
 ```
 
 Sample output from my server (output is trimmed):
 
 ![image](https://user-images.githubusercontent.com/100822553/208468527-5fb5643b-81b5-4b03-902c-eef4790a9c19.png)
 
 ## Conclusion
 
 In this tutorial we learned about openssl commands which can be used to view the content of different kinds of certificates.


