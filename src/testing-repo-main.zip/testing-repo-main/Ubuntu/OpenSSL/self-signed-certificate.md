# OpenSSL create self signed certificate Linux with example

## Table of Contents	

* [Steps required to create self signed certificate in Linux](#Steps-required-to-create-self-signed-certificate-in-Linux)

* [Install openssl](#Install-openssl)

* [Create encrypted password file (Optional)](#Create-encrypted-password-file)

* [Openssl create self signed certificate with passphrase](#Openssl-create-self-signed-certificate-with-passphrase)

   * [Generate private key](#Generate-private-key)

   * [Create Certificate Signing Request (CSR) certificate](#Create-Certificate-Signing-Request )

   * [Create self signed certificate using openssl x509](#Create-self-signed-certificate-using-openssl-x509)

   * [Openssl verify certificate content](#Openssl-verify-certificate-content)

* [Openssl self signed certificate without passphrase](#Openssl-self-signed-certificate-without-passphrase)

   * [Openssl generate private key](#Openssl-generate-private-key)

   * [Create certificate Signing Request (CSR) certificate](#Create-certificate-Signing-Request-(CSR)-certificate)

   * [Create self signed certificate using openssl x509](#Create-self-signed-certificate-using-openssl-x509)

   * [Openssl verify certificate content](#Openssl-verify-certificate-content)

* [Setup Apache with self signed certificate](#Setup-Apache-with-self-signed-certificate)


## Steps required to create self signed certificate in Linux

The steps involved to generate self signed certificate include:

1.Generate private key server.key
2.Create Certificate Signing Request (CSR) `server.csr`
3.Sign the certificate signing request and generate self signed certificate` server.crt`

## Install openssl
On RHEL/CentOS 7/8 you can use yum/dnf respectively while on Ubuntu use apt-get to install openssl rpm
Rhel/centos:-
```
$ yum -y install openssl
```
Ubuntu:- 
```
$ sudo apt-get install openssl
```
## Create encrypted password file (Optional)
. With openssl self signed certificate you can generate private key with and without passphrase.

. If you use any type of encryption while creating private key then you will have to provide passphrase every time you try to access private key.

. With the encrypted password file we can avoid entering the password when we create self signed certificate.

I have created a plain text file `mypass` with my `secret` passphrase
```
[root@centos8-1 ~]# echo secret > mypass
```
Using openssl enc I will encrypt mypass file and create an encrypted file mypass.enc
```
[root@centos8-1 ~]# openssl enc -aes256 -pbkdf2 -salt -in mypass -out mypass.enc
enter aes-256-cbc encryption password:
Verifying - enter aes-256-cbc encryption password:
```
As you see the content of the encrypted file is not readable any more. Now you can easily share this encrypted file to any user to generate ssl certificate
```
[root@centos8-1 ~]# cat mypass.enc
Salted__▒▒Y$▒V΃cQVȥ▒2ĺ)▒MS▒
```
To decrypt the encrypted password file, we use below command:
```
[root@centos8-1 ~]# openssl enc -aes256 -pbkdf2 -salt -d -in mypass.enc
enter aes-256-cbc decryption password:
secret
```
I will create a new directory to store my certificates
```
[root@centos8-1 certs]# mkdir /root/certs
[root@centos8-1 certs]# cd /root/certs
```
I have also copied my encrypted password file to /root/certs
```
[root@centos8-1 certs]# ls -l
total 8
-rw-r--r-- 1 root root   32 Apr  9 13:31 mypass.enc
```
## Openssl create self signed certificate with passphrase
In this section I will share the examples to openssl create self signed certificate with passphrase 
but we will use our encrypted file `mypass.enc` to create private key and other certificate files.

### Generate private key

. We need to generate private key which will use in next steps to create Certificate Signing Request (CSR)

. In this example we will create private key with `3DES` encryption.

. You can also choose any other encyption.

```
[root@centos8-1 certs]# openssl genrsa -des3 -passout file:mypass.enc -out server.key 4096
Generating RSA private key, 4096 bit long modulus (2 primes)
................................................++++
..++++
e is 65537 (0x010001)
```
In this example I have used `-passout` with `file:<filename>`, but you can also use `pass:<passphrase>`, `env:<variable>`, `fd:<number>`. 
You can read more about these options: Network Security with OpenSSL(`https://learning.oreilly.com/library/view/Network+Security+with+OpenSSL/059600270X/ch02.html`). 
if you do not use -passout option, openssl generate private key command would prompt for the passphrase before generating private key.

### Create Certificate Signing Request (CSR) certificate

Next create a certificate signing request (`server.csr`) using the openssl private key (`server.key`).

This command will prompt for a series of things (country, state or province, etc.). 
Make sure that "Common Name" matches the registered fully qualified domain name of your Linux server (or your IP address if you don't have one)

```
[root@centos8-1 certs]# openssl req -new -key server.key -out server.csr -passin file:mypass.enc
You are about to be asked to enter information that will be incorporated
into your certificate request.
What you are about to enter is what is called a Distinguished Name or a DN.
There are quite a few fields but you can leave some blank
For some fields there will be a default value,
If you enter '.', the field will be left blank.
-----
Country Name (2 letter code) [XX]:IN
State or Province Name (full name) []:KARNATAKA
Locality Name (eg, city) [Default City]:BENGALURU
Organization Name (eg, company) [Default Company Ltd]:GoLinuxCloud
Organizational Unit Name (eg, section) []:R&D
Common Name (eg, your name or your server's hostname) []:centos8-1
Email Address []:admin@golinuxcloud.com

Please enter the following 'extra' attributes
to be sent with your certificate request
A challenge password []:
An optional company name []:
```
(Optional) To automate this step to create CSR (`server.csr`) we can either use `openssl.cnf` or create one configuration file with required input as I have shown below:
```
[root@centos8-1 certs]# cat self_signed_certificate.cnf
[req]
distinguished_name = req_distinguished_name
prompt = no
[req_distinguished_name]
C = IN
ST = Karnataka
L = Banaglore
O = GoLinuxCloud
OU = SDM
CN = centos8-1
```
Now to create CSR using this config file (If you have already created server.csr then you can ignore this):

```
[root@centos8-1 certs]# openssl req -new -key server.key -out server.csr -passin file:mypass.enc -config self_signed_certificate.cnf
```
Here we are using `-config` to take input from `self_signed_certificate.cnf file`. But make sure you change CN value based on your server hostname.

### Create self signed certificate using openssl x509
. The openssl x509 command is a multi purpose certificate utility.

. It can be used to display certificate information, convert certificates to various forms, sign certificate requests like a "mini CA" or edit certificate trust settings

. The last step to create self signed certificate is to sign the certificate signing request.

. In this example the openssl certificate will last for 365 days.

. We will use use our private key `server.key` with `server.csr` to sign the certificate and generate self signed certificate server.crt

```
[root@centos8-1 certs]# openssl x509 -req -days 365 -in server.csr -signkey server.key -out server.crt -passin file:mypass.enc
Signature ok
subject=C = IN, ST = Karnataka, L = Banaglore, O = GoLinuxCloud, OU = SDM, CN = centos8-1
Getting Private key
```
So our our openssl generate ssl certificate commands were successful and we have our self signed certificate server.crt

## Openssl verify certificate content

In this article we have create below certificates

`server.key` ⇒ Private Key

`server.csr` ⇒ Certificate Signing Request

`server.crt` ⇒ Self-signed certificate

You can view the content of self signed certificate and other files using openssl:

```
# openssl rsa -noout -text -in server.key
# openssl req -noout -text -in server.csr
# openssl x509 -noout -text -in server.crt
```
## Openssl self signed certificate without passphrase
In this section I will share the examples to create openssl self signed certificate without passphrase.
All the commands and steps will remain the same as we used above to generate self signed certificate, 
the only difference would be that we will not use any encryption method while we create private key in step 1

### Openssl generate private key-------
In this example with openssl genrsa we will not use any encryption:

```
[root@centos8-1 certs]# openssl genrsa -out server-noenc.key 4096
Generating RSA private key, 4096 bit long modulus (2 primes)
................................................................++++
...................................................................................................++++
e is 65537 (0x010001)
```
As expected the openssl generate private key was executed without prompting for any passphrase.

### Create certificate Signing Request (CSR) certificate
Next we will create CSR certificate using our private key. Again make sure you provide proper Common Name value and it should match the hostname/FQDN of your server's detail where you plan to use this certificate.
```
[root@centos8-1 certs]# openssl req -new -key server-noenc.key -out server-noenc.csr
You are about to be asked to enter information that will be incorporated
into your certificate request.
What you are about to enter is what is called a Distinguished Name or a DN.
There are quite a few fields but you can leave some blank
For some fields there will be a default value,
If you enter '.', the field will be left blank.
-----
Country Name (2 letter code) [XX]:IN
State or Province Name (full name) []:KARNATAKA
Locality Name (eg, city) [Default City]:BENGALURU
Organization Name (eg, company) [Default Company Ltd]:GoLinuxCloud
Organizational Unit Name (eg, section) []:R&D
Common Name (eg, your name or your server's hostname) []:centos8-1
Email Address []:admin@golinuxcloud.com

Please enter the following 'extra' attributes
to be sent with your certificate request
A challenge password []:
An optional company name []:
```
To automate this step again you can create a configuration file as we created in this step....

### Create self signed certificate using openssl x509

Now in the last step using openssl `x509` we will create and sign our certificate using `server-noenc.key` and `server-noenc.csr`

```
[root@centos8-1 certs]# openssl x509 -req -days 365 -in server-noenc.csr -signkey server-noenc.key -out server-noenc.crt
Signature ok
subject=C = IN, ST = KARNATAKA, L = BENGALURU, O = GoLinuxCloud, OU = R&D, CN = centos8-1, emailAddress = admin@golinuxcloud.com
Getting Private key
```
## Setup Apache with self signed certificate

After you create self signed certificates, you can these certificate and key to set up Apache with SSL (although browser will complain of insecure connection).

Transfer `server.crt` and `server.key` to your Apache server and then define below values inside Virtual Hosting of `/etc/https/conf/httpd.conf` file
```
SSLEngine On
SSLCertificateFile /path/to/server.crt
SSLCertificateKeyFile /path/to/server.key
```
Next restart your httpd service

Lastly I hope the steps from the article to openssl create self signed certificate Linux was helpful. 
