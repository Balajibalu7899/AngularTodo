# Create Certificate Authority and sign a certificate with Root CA
## Table of Contents

* [Install OpenSSL](#install-OpenSSL)

* [OpenSSL encrypted data with salted password](#openSSL-encrypted-data-with-salted-password)

* [Generate Private Key](#Generate-Private-Key)
  * [OpenSSL verify Private Key content](#OpenSSL-verify-Private-Key-content)
        
* [Create Certificate Authority Certificate](#Create-Certificate-Authority-Certificate)
  * [OpenSSL verify CA certificate](#OpenSSL-verify-CA-certificate)
          
* [Generate a server key and request for signing (CSR)](#Generate-a-server-key-and-request-for-signing)
  * [OpenSSL verify server key content](#OpenSSL-verify-server-key-content)
  * [OpenSSL verify Certificate Signing Request (CSR)](#OpenSSL-verify-Certificate-Signing-Request)
          
* [Sign a certificate with CA](#Sign-a-certificate-with-CA)
  * [OpenSSL verify server certificate](#OpenSSL-verify-server-certificate)

In this article I will share the steps to create Certificate Authority Certificate and then use this CA certificate to sign a certificate.

These are the brief list of steps to create Certificate Authority using OpenSSL:

* Create private key to be used for the certificate.
* Create certificate Authority from the key that you just generated.
* Create Certificate Signing Request for your server.
* Sign the certificate signing request using the key from your CA certificate.

## Install OpenSSL
On RHEL/CentOS 7/8 you can use `yum or dnf` respectively while on Ubuntu use `apt-get` to install openssl rpm

## OpenSSL encrypted data with salted password

When we create private key for Root CA certificate, we have an option to either use encryption for private key or create key without any encryption. As if we choose to create private key with encryption such as 3DES, AES then you will have to provide a passphrase every time you try to access the private key.

I have already written another article with the steps for openssl encd data with salted password to encrypt the password file(https://www.golinuxcloud.com/generate-self-signed-certificate-openssl/#Create_encrypted_password_file_Optional). So I will not repeat the steps here again.

We will use the same encrypted password file for all our examples in this article to demonstrate openssl create certificate chain examples.

## Generate Private Key

First generate private key `ca.key`, we will use this private key to create Certificate Authority certificate

```
[root@centos8-1 certs]# openssl genrsa -des3 -passout file:mypass.enc -out ca.key 4096
Generating RSA private key, 4096 bit long modulus (2 primes)
.............................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................++++
....................................++++
e is 65537 (0x010001)
```
### OpenSSL verify Private Key content
To verify the content of private key we created above use openssl command as shown below:
```
[root@centos8-1 certs]# openssl rsa -noout -text -in ca.key -passin file:mypass.enc
```
## Create Certificate Authority Certificate

Now we will use the private key with openssl to create certificate authority certificate ca.cert.pem. OpenSSL uses the information you specify to compile a X.509 certificate using the information prompted to the user, the public key that is extracted from the specified private key which is also used to generate the signature.
```
[root@centos8-1 certs]# openssl req -new -x509 -days 365 -key ca.key -out ca.cert.pem -passin file:mypass.enc
You are about to be asked to enter information that will be incorporated
into your certificate request.
What you are about to enter is what is called a Distinguished Name or a DN.
There are quite a few fields but you can leave some blank
For some fields there will be a default value,
If you enter '.', the field will be left blank.
-----
Country Name (2 letter code) [XX]:IN
State or Province Name (full name) []:Karnataka
Locality Name (eg, city) [Default City]:Bengaluru
Organization Name (eg, company) [Default Company Ltd]:GoLinuxCloud
Organizational Unit Name (eg, section) []:R&D
Common Name (eg, your name or your server's hostname) []:centos8-1 CA
Email Address []:admin@golinuxcloud.com
```
### OpenSSL verify CA certificate
To verify CA certificate content using openssl:
```
[root@centos8-1 certs]# openssl x509 -noout -text -in ca.cert.pem
Certificate:
    Data:
        Version: 3 (0x2)
        Serial Number:
            4a:73:47:ce:49:c6:a7:ab:36:ad:b8:56:bc:73:3a:e4:63:f7:93:14
        Signature Algorithm: sha256WithRSAEncryption
        Issuer: C = IN, ST = Karnataka, L = Bengaluru, O = GoLinuxCloud, OU = R&D, CN = centos8-1 CA, emailAddress = admin@golinuxcloud.com
        Validity
            Not Before: Apr 11 15:45:10 2020 GMT
            Not After : Apr 11 15:45:10 2021 GMT
        Subject: C = IN, ST = Karnataka, L = Bengaluru, O = GoLinuxCloud, OU = R&D, CN = centos8-1 CA, emailAddress = admin@golinuxcloud.com
        Subject Public Key Info:
            Public Key Algorithm: rsaEncryption
                RSA Public-Key: (4096 bit)

             <Output trimmed>

        X509v3 extensions:
            X509v3 Subject Key Identifier:
                04:A6:1C:8B:4B:6C:B9:47:3D:A7:FB:38:CA:91:C0:B5:28:A5:BE:94
            X509v3 Authority Key Identifier:
                keyid:04:A6:1C:8B:4B:6C:B9:47:3D:A7:FB:38:CA:91:C0:B5:28:A5:BE:94

            X509v3 Basic Constraints: critical
                CA:TRUE

            <Output trimmed>
```
## Generate a server key and request for signing (CSR)
This step creates a server key, and a request that you want it signed (the .csr file) by a Certificate Authority
```
[root@centos8-1 certs]# openssl genrsa -des3 -passout file:mypass.enc -out server.key 4096
Generating RSA private key, 4096 bit long modulus (2 primes)
.....................................++++
...........................................................................................................++++
e is 65537 (0x010001)
```

We now generate a Certificate Signing Request which contains some of the info that we want to be included in the certificate. To prove ownership of the private key, the CSR is signed with the subject's private key `server.key`.Think carefully when inputting a Common Name (CN) as you generate the .csr file below. This should match the DNS name, or the IP address you specify in your Apache configuration.

```
[root@centos8-1 certs]# openssl req -new -key server.key -out server.csr -passin file:mypass.enc
You are about to be asked to enter information that will be incorporated
into your certificate request.
What you are about to enter is what is called a Distinguished Name or a DN.
There are quite a few fields but you can leave some blank
For some fields there will be a default value,
If you enter '.', the field will be left blank.
-----
Country Name (2 letter code) [XX]:IN
State or Province Name (full name) []:Karnataka
Locality Name (eg, city) [Default City]:Bengaluru
Organization Name (eg, company) [Default Company Ltd]:GoLinuxCloud
Organizational Unit Name (eg, section) []:R&D
Common Name (eg, your name or your server's hostname) []:server
Email Address []:admin@golinuxcloud.com

Please enter the following 'extra' attributes
to be sent with your certificate request
A challenge password []:
An optional company name []:
```

### OpenSSL verify server key content
We can use the same command as we used to verify ca.key content
```
[root@centos8-1 certs]# openssl rsa -noout -text -in server.key -passin file:mypass.enc
```

### OpenSSL verify Certificate Signing Request (CSR)

To verify openssl CSR certificate use below command:

```
[root@centos8-1 certs]# openssl req -noout -text -in server.csr
Certificate Request:
    Data:
        Version: 1 (0x0)
        Subject: C = IN, ST = Karnataka, L = Bengaluru, O = GoLinuxCloud, OU = R&D, CN = server, emailAddress = admin@golinuxcloud.com
        Subject Public Key Info:
            Public Key Algorithm: rsaEncryption
                RSA Public-Key: (4096 bit)
                <Output trimmed>
```
## Sign a certificate with CA

In this command we will issue this certificate `server.crt`, signed by the CA root certificate `ca.cert.pem `and CA key ca.key which we created in the previous command.

Openssl takes your signing request (csr) and makes a one-year valid signed server certificate (crt) out of it. In doing so, we need to tell it which Certificate Authority (CA) to use, which CA key to use, and which Server key to sign. We set the serial number using `CAcreateserial`, and output the `signed key` in the file named `server.crt`

```
[root@centos8-1 certs]# openssl x509 -req -days 365 -in server.csr -CA ca.cert.pem -CAkey ca.key -CAcreateserial -out server.crt -passin file:mypass.enc
Signature ok
subject=C = IN, ST = Karnataka, L = Bengaluru, O = GoLinuxCloud, OU = R&D, CN = server, emailAddress = admin@golinuxcloud.com
Getting CA Private Key
```

### OpenSSL verify server certificate

Verify server certificate content using openssl:

```
[root@centos8-1 certs]# openssl x509 -noout -text -in server.crt
Certificate:
    Data:
        Version: 1 (0x0)
        Serial Number:
            69:ee:7f:8f:12:77:b3:0b:75:b8:ac:eb:66:df:bf:50:82:bf:64:b0
        Signature Algorithm: sha256WithRSAEncryption
        Issuer: C = IN, ST = Karnataka, L = Bengaluru, O = GoLinuxCloud, OU = R&D, CN = centos8-1 CA, emailAddress = admin@golinuxcloud.com
        Validity
            Not Before: Apr 11 15:50:23 2020 GMT
            Not After : Apr 11 15:50:23 2021 GMT
        Subject: C = IN, ST = Karnataka, L = Bengaluru, O = GoLinuxCloud, OU = R&D, CN = server, emailAddress = admin@golinuxcloud.com
        Subject Public Key Info:
            Public Key Algorithm: rsaEncryption
                RSA Public-Key: (4096 bit)
                <Output trimmed>
```


`
HINT:
If you use this server.key for your Apache or other services, then it will ask for password every time you restart the respective service. You can choose to remove the passphrase by using openssl rsa -in server.key -out server.key.insecure -passin file:mypass.enc and then use insecure version of server.key for your services
`

Lastly I hope the steps from the article to create Certificate Authority and sign a certificate with a CA on Linux was helpful. 
