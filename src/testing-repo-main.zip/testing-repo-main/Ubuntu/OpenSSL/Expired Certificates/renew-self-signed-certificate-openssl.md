# Renew self-signed certificate OpenSSL [Step-by-Step]

# Table of contents

* [Setup Lab Environment](#Setup-Lab-Environment)
  * [Step-1 Generate Private key](#Step-1-Generate-Private-key)
  * [Step-2 Generate Certificate Signing Request CSR](#Step-2-Generate-Certificate-Signing-Request-CSR)
  * [Step-3 Generate self-signed certificate](#Step-3-Generate-self-signed-certificate)
* [Renew self-signed certificate](#Renew-self-signed-certificate)
  * [Step-1 Check the validity of the self-signed certificate](#Step-1-Check-the-validity-of-the-self-signed-certificate)
  * [Step-2 Export CSR from the expired certificate](#Step-2-Export-CSR-from-the-expired-certificate)
  * [Step-3 Renew self-signed certificate](#Step-3-Renew-self-signed-certificate)
  * [Step-4 Verify renewed certificate](#Step-4-Verify-renewed-certificate)
* [Summary](#Summary)

In this tutorial we will cover step by step details to renew self-signed certificate using openssl command. During any certificate renewal, you always have to make sure that you have a copy of the private key which was used to generate the original certificate. Without the private key, you will not be able to renew any certificate.

In such case you will have to create a new private key and then generate a new certificate.

### Setup Lab Environment
First we will generate one set of self-signed certificates which in later part of this article will be renewed.

I have created a directory `/certs` where I will be performing all the operations.
```
[root@controller ~]# mkdir /certs; cd /certs
```
Following is the` openssl `version which I will use for the demonstration:
```
[root@controller certs]# rpm -q openssl
openssl-1.1.1c-2.el8.x86_64
```

### Step-1 Generate Private key

It is important that you store this private key safely as we would need this later when we renew self-signed certificate:
```
[root@controller certs]# openssl genrsa -out server.key 4096
```
Sample Output:

![image](https://user-images.githubusercontent.com/100822553/208659376-031d0ab4-ab40-495f-a03a-8bd731f4c8ad.png)

### Step-2 Generate Certificate Signing Request CSR

Next we need to generate a Certificate Signing Request. You can provide the hostname of your local Linux server as `Common Name`

```
[root@controller certs]# openssl req -new -key server.key -out server.csr
```
Sample output:

![image](https://user-images.githubusercontent.com/100822553/208659614-4222083c-ef5d-4610-ad13-c2b99d6c3bd4.png)

So, at this stage we have following two certificate files:

```
[root@controller certs]# ls -l
total 8
-rw-r--r-- 1 root root 1720 Aug 27 09:41 server.csr
-rw------- 1 root root 3243 Aug 27 09:40 server.key
```
### Step-3 Generate self-signed certificate

We normally don't modify any X.509 extensions while working with self-signed certificate as they are only used for TLS authentication but they are never preferred for MTLS Authentication. So we will create our self-signed certificate without any changes to X.509 extensions or SAN field.

Now that we have the private key and CSR, we can go ahead and generate our self signed certificate:
```
[root@controller certs]# openssl x509 -req -days 365 -in server.csr -signkey server.key -out server.crt
Signature ok
subject=C = IN, ST = Karnataka, L = Bangalore, O = GoLinuxCloud, OU = Admin, CN = controller.example
Getting Private key
```
So, we have successfully generated our self-signed certificate. You can check the content of this certificate using:

```
openssl x509 -noout -text -in server.crt
```
## Renew self-signed certificate

Now that we have our self-signed certificate, we will next learn how to renew self-signed certificates.

### Step-1 Check the validity of the self-signed certificate

First let's check the validity of the certificate:

```
[root@controller certs]# openssl x509 -noout -text -in server.crt | grep -i -A2 validity
```
Sample Output:

![image](https://user-images.githubusercontent.com/100822553/208660667-35238e8c-f02a-4549-b444-4783bea8d69f.png)

So our certificate will expire on 27 Aug 2022 and today is 27 Aug 2021.

Obviously we can't wait for another 1 year to learn this part right? Or you may come back in 1 year 🙂

So let's assume 1 year has passed by and now we want to renew this certificate.

### Step-2 Export CSR from the expired certificate
Now you may either generate a new CSR or export the CSR from the existing expired self-signed certificate.

It is recommended to export the CSR as you don't have to worry about giving the same Distinguished Name information. Although this information can be collected from the certificate itself.

For us, we will export the CSR from the certificate itself:
```
[root@controller certs]# openssl x509 -x509toreq -in server.crt -signkey server.key -out new-server.csr
Getting request Private Key
Generating certificate request
```
Verify the new CSR is properly created:

![image](https://user-images.githubusercontent.com/100822553/208660844-46825d95-cbd4-436a-9725-25ff017a8144.png)

To check the content of CSR file:
```
[root@controller certs]# openssl req -noout -text -in new-server.csr
```

### Step-3 Renew self-signed certificate

Now that we have our private key and CSR, we can renew our certificate. You should not get confused with the term "renew", we are not extending the expiry of the certificate, instead we are just creating a new self signed certificate using the existing CSR and private key so the Signature Modulus is same and our application considers the certificate as same instead of new.
```
[root@controller certs]#  openssl x509 -req -days 365 -in new-server.csr -signkey server.key -out new-server.crt
Signature ok
subject=C = IN, ST = Karnataka, L = Bangalore, O = GoLinuxCloud, OU = Admin, CN = controller.example
Getting Private key
```
So, we have successfully renewed our self-signed certificate.

![image](https://user-images.githubusercontent.com/100822553/208661034-f2056ae8-6aa3-44d1-a7b7-26e0a49cab7f.png)

### Step-4 Verify renewed certificate

You can check the checksum of both existing and new certificate:
```
[root@controller certs]# sha256sum server.crt
594a31a4ee5283177e08b050e9ab919dd7f04a30aed00a87d1010de8f7048754  server.crt

[root@controller certs]# sha256sum new-server.crt
39fea6346ebbc9a2d265af232561540fac0cc3ecff9f2e9e65b13731fa3228ac  new-server.crt
```
So the checksum of both the certificates are different.

But then what is important that Signature of both these certificate will be same which you can check as shown below.

Here is the signature for `server.crt`:

```
[root@controller certs]# openssl x509 -noout -text -in server.crt
Certificate:
    Data:
        Version: 1 (0x0)
        Serial Number:
            10:c0:c6:7c:5c:95:fe:6b:dd:e6:df:b8:f4:d3:53:cd:6e:33:93:ca
        Signature Algorithm: sha256WithRSAEncryption
        Issuer: C = IN, ST = Karnataka, L = Bangalore, O = GoLinuxCloud, OU = Admin, CN = controller.example
        Validity
            Not Before: Aug 27 04:11:52 2021 GMT
            Not After : Aug 27 04:11:52 2022 GMT
        Subject: C = IN, ST = Karnataka, L = Bangalore, O = GoLinuxCloud, OU = Admin, CN = controller.example
        Subject Public Key Info:
            Public Key Algorithm: rsaEncryption
                RSA Public-Key: (4096 bit)
                Modulus:
                    00:b4:3b:a9:e2:9b:93:7b:8b:4c:35:72:18:dd:b8:
                    b8:09:a9:8c:8d:75:15:07:18:5a:60:17:b3:93:29:
                    ae:5c:4c:af:5a:1b:ee:90:eb:2d:79:1d:2e:2f:54:
                    e9:18:3d:ba:f3:fd:fc:86:66:5b:af:2f:03:b7:74:
                    6d:85:33:d0:b7:d2:a4:d9:23:3d:37:c5:9e:0d:0e:
                    aa:f3:47:34:ef:44:71:ac:d2:de:86:67:c1:82:09:
                    96:1a:30:bf:66:20:89:d8:ef:90:5f:cc:2e:c5:16:
                    5f:eb:c5:1c:e3:b3:09:97:d4:5c:18:85:66:1e:40:
                    88:f4:47:f0:f6:78:e2:f7:df:2b:43:54:09:56:16:
                    ca:d2:01:2c:dc:d2:46:34:50:ee:81:5b:2e:57:cc:
                    32:63:4b:b1:05:26:d0:73:ba:f9:2f:bb:f3:85:ac:
                    0e:ef:63:34:d2:5d:d2:d9:bc:81:46:42:61:f6:d6:
                    71:16:6d:53:41:fd:21:08:51:3b:87:d9:50:4c:54:
                    c9:1d:f3:ca:a2:f9:67:23:58:db:85:2f:3c:01:55:
                    51:15:a9:e9:99:1d:2b:90:8f:1b:16:c4:fb:d5:e7:
                    2d:93:39:7f:2d:a2:cf:b6:b2:1e:e0:e4:b9:f4:ad:
                    8a:12:c6:51:43:5d:b7:d3:fd:2a:e0:98:bf:2c:e2:
                    9b:24:a9:68:9e:10:e2:ee:59:72:e6:b8:c0:67:c8:
                    9a:82:b0:7b:a1:d5:e8:84:a9:b1:7d:ef:40:fb:01:
                    c4:7c:aa:54:8e:3c:07:82:00:db:14:ce:6d:ca:a6:
                    9a:98:f3:41:1c:e9:5c:69:54:80:a6:fd:af:19:74:
                    a9:fd:cf:8d:80:0c:c7:b0:78:2b:1b:df:e5:52:d1:
                    84:53:8a:1e:12:5e:c8:a2:2d:ef:2d:fe:92:8b:1d:
                    d5:d3:41:a5:47:49:94:98:5b:8f:25:9d:9f:04:47:
                    19:ff:3b:8a:cb:f9:10:57:e2:b5:b7:a6:b6:88:80:
                    e4:21:5b:36:4c:f2:d6:94:99:57:d2:7e:81:d9:e8:
                    4e:cc:72:2a:3d:2f:72:a2:7d:2c:e1:33:d9:60:35:
                    17:7e:97:04:cd:1c:52:4a:1c:ef:74:9d:73:57:fe:
                    5d:77:44:99:f9:4b:4b:e9:1a:27:7f:2b:5c:f7:3d:
                    b7:6b:20:e5:c0:7f:26:40:eb:80:42:43:41:f5:c3:
                    5e:e4:d2:96:c3:43:4b:61:0f:8a:ad:99:0a:06:8d:
                    84:23:cb:7c:47:9e:66:fc:dc:b1:09:80:40:6a:9b:
                    9d:ee:83:b9:60:94:f2:9b:fc:ec:b4:8e:60:58:5d:
                    bf:e1:3f:97:c2:ee:6b:87:f3:e9:3a:31:60:2d:64:
                    5d:85:0f
                Exponent: 65537 (0x10001)
                .....

```
Compare this with `new-server.crt` certificate:

```
[root@controller certs]# openssl x509 -noout -text -in new-server.crt
Certificate:
    Data:
        Version: 1 (0x0)
        Serial Number:
            16:a4:85:9e:c1:de:6e:06:55:ac:15:6a:f4:9a:05:4e:70:04:3a:11
        Signature Algorithm: sha256WithRSAEncryption
        Issuer: C = IN, ST = Karnataka, L = Bangalore, O = GoLinuxCloud, OU = Admin, CN = controller.example
        Validity
            Not Before: Aug 27 05:14:21 2021 GMT
            Not After : Aug 27 05:14:21 2022 GMT
        Subject: C = IN, ST = Karnataka, L = Bangalore, O = GoLinuxCloud, OU = Admin, CN = controller.example
        Subject Public Key Info:
            Public Key Algorithm: rsaEncryption
                RSA Public-Key: (4096 bit)
                Modulus:
                    00:b4:3b:a9:e2:9b:93:7b:8b:4c:35:72:18:dd:b8:
                    b8:09:a9:8c:8d:75:15:07:18:5a:60:17:b3:93:29:
                    ae:5c:4c:af:5a:1b:ee:90:eb:2d:79:1d:2e:2f:54:
                    e9:18:3d:ba:f3:fd:fc:86:66:5b:af:2f:03:b7:74:
                    6d:85:33:d0:b7:d2:a4:d9:23:3d:37:c5:9e:0d:0e:
                    aa:f3:47:34:ef:44:71:ac:d2:de:86:67:c1:82:09:
                    96:1a:30:bf:66:20:89:d8:ef:90:5f:cc:2e:c5:16:
                    5f:eb:c5:1c:e3:b3:09:97:d4:5c:18:85:66:1e:40:
                    88:f4:47:f0:f6:78:e2:f7:df:2b:43:54:09:56:16:
                    ca:d2:01:2c:dc:d2:46:34:50:ee:81:5b:2e:57:cc:
                    32:63:4b:b1:05:26:d0:73:ba:f9:2f:bb:f3:85:ac:
                    0e:ef:63:34:d2:5d:d2:d9:bc:81:46:42:61:f6:d6:
                    71:16:6d:53:41:fd:21:08:51:3b:87:d9:50:4c:54:
                    c9:1d:f3:ca:a2:f9:67:23:58:db:85:2f:3c:01:55:
                    51:15:a9:e9:99:1d:2b:90:8f:1b:16:c4:fb:d5:e7:
                    2d:93:39:7f:2d:a2:cf:b6:b2:1e:e0:e4:b9:f4:ad:
                    8a:12:c6:51:43:5d:b7:d3:fd:2a:e0:98:bf:2c:e2:
                    9b:24:a9:68:9e:10:e2:ee:59:72:e6:b8:c0:67:c8:
                    9a:82:b0:7b:a1:d5:e8:84:a9:b1:7d:ef:40:fb:01:
                    c4:7c:aa:54:8e:3c:07:82:00:db:14:ce:6d:ca:a6:
                    9a:98:f3:41:1c:e9:5c:69:54:80:a6:fd:af:19:74:
                    a9:fd:cf:8d:80:0c:c7:b0:78:2b:1b:df:e5:52:d1:
                    84:53:8a:1e:12:5e:c8:a2:2d:ef:2d:fe:92:8b:1d:
                    d5:d3:41:a5:47:49:94:98:5b:8f:25:9d:9f:04:47:
                    19:ff:3b:8a:cb:f9:10:57:e2:b5:b7:a6:b6:88:80:
                    e4:21:5b:36:4c:f2:d6:94:99:57:d2:7e:81:d9:e8:
                    4e:cc:72:2a:3d:2f:72:a2:7d:2c:e1:33:d9:60:35:
                    17:7e:97:04:cd:1c:52:4a:1c:ef:74:9d:73:57:fe:
                    5d:77:44:99:f9:4b:4b:e9:1a:27:7f:2b:5c:f7:3d:
                    b7:6b:20:e5:c0:7f:26:40:eb:80:42:43:41:f5:c3:
                    5e:e4:d2:96:c3:43:4b:61:0f:8a:ad:99:0a:06:8d:
                    84:23:cb:7c:47:9e:66:fc:dc:b1:09:80:40:6a:9b:
                    9d:ee:83:b9:60:94:f2:9b:fc:ec:b4:8e:60:58:5d:
                    bf:e1:3f:97:c2:ee:6b:87:f3:e9:3a:31:60:2d:64:
                    5d:85:0f
                Exponent: 65537 (0x10001)
                ...
```
As you can verify, both have the same signature.

## Summary
In this tutorial we shared step by step instructions to renew self-signed certificate using OpenSSL in Linux. Normally in production environment we don't renew self-signed certificate, instead we provide a very long expiry date based on the product lifecycle. This is because self-signed are use for normal TLS authentication which is less secure compared to MTLS. So we prefer to use MTLS authentication with RootCA and server/client certificates which are renewed periodically.
