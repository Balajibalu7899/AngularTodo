 [Readme Generator](https://readme.so/editor)

# How to revoke missing/lost certificate OpenSSL [Step-by-Step]

## Table of Contents

* [Revoke missing or lost certificate with OpenSSL](#Revoke-missing-or-lost-certificate-with-OpenSSL)
* [Pre-requisites](#Pre-requisites)
* [Lab Environment](#Lab-Environment)
* [Understand index.txt format](#Understand-index.txt-format)
* [Identify your RootCA database file and serial number](#Identify-your-RootCA-database-file-and-serial-number)
* [Generate revocation date and time](#Generate-revocation-date-and-time)
* [Manually update the CA certificate database to revoke missing certificate](#Manually-update-the-CA-certificate-database-to-revoke-missing-certificate)
* [Generate Certificate Revocation List CRL](#Generate-Certificate-Revocation-List-CRL)
* [Verify the CRL for the revoked certificate](#Verify-the-CRL-for-the-revoked-certificate)
* [Summary](#Summary)
* [References](#References)

## Revoke missing or lost certificate with OpenSSL

We may end up in a situation where one of our certificates goes missing or we loose it for some reason such as node crash or anything else. In such case CA will now allow to create a new certificate using the same Common Name. 
Although there are hacks to create [duplicate certificates](https://www.golinuxcloud.com/generate-duplicate-certificates-openssl/) using the same Common Name with OpenSSL but we should always try to revoke a certificate in such scenarios to avoid security related issues.
But normally to revoke a certificate we also need the actual certificate file but in this case we actually don't have the certificate. So how do we revoke missing or lost certificate using OpenSSL?

`IMPORTANT NOTE`: `The steps from this article is a sort of a hack to manually update the CA database. Manually updating the CA database is always tricky as there is a possibility of corruption which can impact all the certificates signed by the RootCA so always take a backup. Based on the updated database entry we can also generate the CRL which will consider the certificate as invalid.`

## Pre-requisites

You must have read and write access to the respective RootCA's database which maintains the details of all the certificates it has signed.

If you have multiple CA certificates or a CA bundle then you must properly verify the `index.txt` database which should be modified as we don't have the actual certificate so we will be directly modifying the `index.txt` of the CA certificate database.

## Lab Environment

I already have a setup where I had created my root CA certificate inside `/root/tls` directory. Here are the steps required to create one (added just for reference):

```
## navigate inside your tls path
cd /root/tls

## generate rootca private key
openssl genrsa  -out private/cakey.pem 4096

## generate rootCA certificate
openssl req -new -x509 -days 3650  -config openssl.cnf  -key private/cakey.pem -out certs/cacert.pem

## Verify the rootCA certificate content and X.509 extensions
openssl x509 -noout -text -in certs/cacert.pem
```

You can collect my sample openssl.cnf from a different article.

## Understand index.txt format

Now if you are already familiar with the format of `index.txt` file and you know what you are doing then you can skip this section:

The index file consists of zero or more lines, each containing the following fields separated by tab characters:

* First column contains the `certificate status flag` `(V=valid, R=revoked, E=expired)`.
* Second column contains the `certificate expiration` date in `YYMMDDHHMMSSZ` format.
* Third column contains the `certificate revocation` date in `YYMMDDHHMMSSZ[,reason]` format. Empty if not revoked.
* Fourth column contains the `certificate serial` number in hex.
* Fifth column contains the `certificate filename` or literal string ‘unknown’.
* Sixth column contains the `certificate distinguished name`.

## Identify your RootCA database file and serial number

Now that you are familiar with the content of CA database, let us continue with the certificate revocation.

As I also mentioned earlier, you must have access to your CA's database as we will manually update the `index.txt` to mark our certificate as revoked.

Here are the list of certificates which are signed by my RootCA:

```
[root@controller tls]# cat /root/tls/index.txt
V       210915120854Z           01      unknown /C=IN/ST=karnataka/O=golinuxcloud/OU=admin/CN=server-1.example.com
V       210915120949Z           02      unknown /C=IN/ST=karnataka/O=golinuxcloud/OU=admin/CN=server-2.example.com
V       210915121028Z           03      unknown /C=IN/ST=karnataka/O=golinuxcloud/OU=test/CN=server-3.example.com
```

Here, suppose we lose the certificate for `server-1.example.com` so we basically want to revoke certificate generated with serial` 01`.

Now there is no such command which would actually use serial number to revoke the certificate. Following is the command syntax used to revoke any certificate:

```
openssl ca -config <openssl_config_file_path> -revoke <bad_certificate>
```

So, we will hack the `index.txt` file and manually mark the certificate as revoked.


## Generate revocation date and time

As we know the third column contains the revocation date and timestamp. So let us generate the same using date command. Use the following command:

```
# date '+%y%m%d%k%M%SZ'
210905182109Z
```
## Manually update the CA certificate database to revoke missing certificate

Next we will go ahead and modify our CA database to mark certificate from serial `01` as revoked. Take a backup of your `index.txt` file (just in case if required for fallback purpose):

```
# cp index.txt index.txt.bkp
```

Next add the following entry as the first line in the index.txt file:

`IMPORTANT NOTE`:Do not use space key to add whitespace inside the `index.txt` file. Always use TAB button to add the whitespace between different columns

```
R       210915120854Z   210905182109Z   01      unknown /C=IN/ST=karnataka/O=golinuxcloud/OU=admin/CN=server-1.example.com
```
Here we updated:

* First column we changed the certificate status flag to R to mark the certificate as Revoked
* Second column remains the same
* Third column is updated with the date command output we got in Step-2 of this article
* Fourth column is updated with the serial number of the certificate which has been revoked
* Fifth column contains the filename or literal string, `unknown`
* Sixth column contains the distinguished name of the certificate which has been revoked, i.e. the same from serial `01` in our case.

So, this is how our index.txt looks now:

![image](https://user-images.githubusercontent.com/100822553/208648762-7a0d0757-b90f-4323-85b4-62129f6efba6.png)

## Generate Certificate Revocation List CRL

Now that our CA database is  updated, next we need to generate our CRL. if you have a CRL already with you then you can just update your existing CRL using the following command:

```
]# openssl ca -config /root/tls/openssl.cnf -gencrl -out /root/tls/crl/rootca-1.crl
Using configuration from /root/tls/openssl.cnf
```

## Verify the CRL for the revoked certificate
You can check the content of your CRL to get the list of the revoked certificates using following command:
```
openssl crl -in /root/tls/crl/rootca.crl -text -noout
```
Sample Output:
![image](https://user-images.githubusercontent.com/100822553/208649054-291b6454-c734-4c52-a1ca-201a2ba6007e.png)

As you can see, the following certificate has been revoked:

```
Revoked Certificates:
    Serial Number: 01
        Revocation Date: Sep  5 18:21:09 2021 GMT
```
Now you obviously don't have your certificate so you can't perform this step, but let me show you what would happen if someone tries to use the certificate which has been revoked. We will combined our CA certificate along with the CRL file to perform the validation:
```
# cat crl/rootca.crl certs/cacert.pem > /tmp/test.pem
```
Next verify the integrity of the certificate using the newly created PEM file:

```
# openssl verify -extended_crl -verbose -CAfile /tmp/test.pem -crl_check /certs/server-1.crt
C = IN, ST = karnataka, O = golinuxcloud, OU = admin, CN = server-1.example.com
error 23 at 0 depth lookup: certificate revoked
error /certs/server-1.crt: verification failed
```
As you can see, the verification failed because the certificate has been marked revoked by the CRL

So you can update your application to use this CRL to make sure the lost certificate is not used by any intruder to access your application.

##  Summary
In this tutorial I shared the steps to revoke missing certificate or revoke any certificate which has been lost and you don't have the certificate with you anymore. In such case we can manually hack the CA database to mark the lost certificate as revoked by using the respective serial number. it is important to generate or update the Certificate Revocation list (CRL) which will be used by the application to validate any certificate.
Once the CRL is updated, anyone using your lost certificate will not be able to perform a secure communication.

## References
https://www.golinuxcloud.com/revoke-missing-lost-certificate-openssl/
