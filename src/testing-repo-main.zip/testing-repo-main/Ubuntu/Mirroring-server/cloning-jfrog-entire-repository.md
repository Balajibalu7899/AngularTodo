### Mirroring the jfrog repository to local mirror server using script
Jfrog doesn't support Mirroring the repository using mirroring tools like apt-mirror, so we are downloading the entire jfrog Debian repository to the mirror server using shell script, once it is downloaded to the mirror server we are gonna server the packages to the clients using the apache2 web server.
Before running the shell script you need to download the jfrog cli in the system where you are running this script. 
```
wget -qO - https://releases.jfrog.io/artifactory/jfrog-gpg-public/jfrog_public_gpg.key | sudo apt-key add -
echo "deb https://releases.jfrog.io/artifactory/jfrog-debs xenial contrib" | sudo tee -a /etc/apt/sources.list &&    sudo apt update &&
sudo apt install -y jfrog-cli-v2-jf &&
jf intro
```
For more information on downloading jfrog cli for specific platform refer
```
https://jfrog.com/getcli/
```

Jfrog Cli download URL :- https://jfrog.com/getcli/ 

once jfrog cli is downloaded then create a file that will clone the entire jfrog cli to our laptop
for ex:; Iam gonna name this script as jfrog-pull-repo-v1.sh and copy paste the below code into that file and replace the values accourding to your need and run the file.

```
#!/bin/bash

PATH='/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin'
JFROG_URL='your artifactory url'
JFROG_ACCESS_TOKEN='your Jfrog access token here'
JFROG_REPOSITORY='your jfrog repo name'
DESTINATION_DIR='/var/www/html/ubuntu'
LOCAL_TXT="${DESTINATION_DIR}/$$-local.txt"
REMOTE_TXT="${DESTINATION_DIR}/$$-remote.txt"

test -e ${DESTINATION_DIR} || mkdir -p ${DESTINATION_DIR} 

export CI=true

if test -d ${DESTINATION_DIR}/${JFROG_REPOSITORY};
  then
    # Fetch remote repository files/folder path
    jf rt search --url ${JFROG_URL} \
       --access-token ${JFROG_ACCESS_TOKEN} \
       ${JFROG_REPOSITORY} --include-dirs | \
       jq '.[]|.path' /tmp/out.txt | \
       sed 's/\"//g' | \
       sort > ${REMOTE_TXT}

    # Get remote repository files/folder path
    find ${DESTINATION_DIR}/${JFROG_REPOSITORY} | \
       sed "s#${DESTINATION_DIR}/##g" | \
       sort > ${LOCAL_TXT} 

    diff <(tail -n +2 ${LOCAL_TXT}) <(tail -n +2 ${REMOTE_TXT})


    # Download repository if file/folder structure is different between local and remote repositories
    if test $? -ne 0;
      then
        # Download remote repository
        jf rt dl --url ${JFROG_URL} \
	   --access-token ${JFROG_ACCESS_TOKEN} \
	   ${JFROG_REPOSITORY} ${DESTINATION_DIR}/${JFROG_REPOSITORY}.$(date +%d%m%Y).$$/ 
    
        # Remove the old local repository if downloaded successfully else revert.
        if test $? -eq 0;
          then
    	    mv ${DESTINATION_DIR}/${JFROG_REPOSITORY} ${DESTINATION_DIR}/${JFROG_REPOSITORY}.$(date +%d%m%Y).ori
    	    mv ${DESTINATION_DIR}/${JFROG_REPOSITORY}.$(date +%d%m%Y).$$ ${DESTINATION_DIR}/${JFROG_REPOSITORY}
    	    rm -fr ${DESTINATION_DIR}/${JFROG_REPOSITORY}.$(date +%d%m%Y).ori
          else
    	    rm -fr ${DESTINATION_DIR}/${JFROG_REPOSITORY}.$(date +%d%m%Y).$$
        fi 
    fi
  else
    # Download remote repository
    jf rt dl --url ${JFROG_URL} \
       --access-token ${JFROG_ACCESS_TOKEN} \
       ${JFROG_REPOSITORY} ${DESTINATION_DIR}/${JFROG_REPOSITORY}/ 
fi

# Cleanup
rm -f ${LOCAL_TXT} ${REMOTE_TXT}


```
 
The above file contains the script to download the jfrog repository. 

JFROG_URL='https://mcd.jfrog.io/artifactory'

JFROG_ACCESS_TOKEN='your Jfrog access token here'

JFROG_REPOSITORY='pos2-Debian-poc' (you can give the jfrog Debian repository name here)

DESTINATION_DIR='/var/www/html/ubuntu'

in DESTINATION_DIR you need to mention the directory path to which the repository need to download , in my case i have given /var/www/html/ubuntu ,- pos2-Debian-poc repository will be downloaded into this path after running the above script.

To Execute the script run  below command in terminal.

```
$ sudo bash -x jfrog-pull-repo-v1.sh     
```
