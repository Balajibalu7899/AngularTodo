# How to use Ansible managed nodes without Python

If you remember during the Lab Environment setup with Pre-requisites I had mentioned that Python is a mandatory pre-requisite to be able to work with Ansible. Now not necessarily but you do have a work around to be able to use Ansible managed nodes without Python.

 

For this demonstration I have removed python from `server2` and now I try to collect the `uptime `from this managed node:

```
[ansible@controller ~]$ ansible server2 -m shell -a uptime
[WARNING]: No python interpreters found for host server2 (tried ['/usr/bin/python', 'python3.7',
'python3.6', 'python3.5', 'python2.7', 'python2.6', '/usr/libexec/platform-python', '/usr/bin/python3',
'python'])
server2 | FAILED! => {
    "ansible_facts": {
        "discovered_interpreter_python": "/usr/bin/python"
    },
    "changed": false,
    "module_stderr": "Shared connection to server2 closed.\r\n",
    "module_stdout": "/bin/sh: /usr/bin/python: No such file or directory\r\n",
    "msg": "The module failed to execute correctly, you probably need to set the interpreter.\nSee stdout/stderr for the exact error",
    "rc": 127
}
```
As expected, the command execution has failed as it `couldn't find a valid interpreter`. To overcome such challenges, you can use "`raw`" module:

 

For example here we are using `raw` module to get the uptime of the remote managed node:

```
[ansible@controller ~]$ ansible server2 -m raw -a uptime
server2 | CHANGED | rc=0 >>
 07:14:38 up  1:50,  2 users,  load average: 0.00, 0.00, 0.00
Shared connection to server2 closed.
```
But the existing syntax of python modules which we have learned `will not work with raw module`.

As per [official ansible documentation](https://docs.ansible.com/ansible/latest/collections/ansible/builtin/raw_module.html) on raw module:

* Executes a low-down and `dirty SSH command`, not going through the module subsystem.
* This is useful and should only be done in a few cases. A common case is installing python on a system without python installed by default. Another is speaking to any devices such as routers that do not have any Python installed. In any other case, `using the shell or command module is much more appropriate`.
* Arguments given to `raw` are run directly through the configured remote shell.
* Standard output, error output and return code are returned when available.
* There is no change `handler` support for this module.
* This module does not require python on the remote system, much like the script module.
* This module is `also supported` for Windows targets.

