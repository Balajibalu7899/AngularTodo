# Writing Ansible playbook with Visual Studio Code

## Table of Contents

* [Download Visual Studio Code Repo](#Download-Visual-Studio-Code-Repo)
* [Access Visual Code Studio](#Access-Visual-Code-Studio)
* [Install Ansible Extension](#Install-Ansible-Extension)
* [Create playbook using Visual Studio](#Create-playbook-using-Visual-Studio)
* [Further Reading](#Further-Reading)

Now that you are familiar with writing ansible playbooks, in this section we will use Visual Studio Code Editor to write playbooks instead of CLI. You will need GUI based Linux environment for this part of tutorial. If your CentOS or Red Hat is not installed with GUI Desktop then you can install GNOM Desktop or Workstation using DNF or YUM.

-----------------------------------------------------
## Download Visual Studio Code Repo

You can get the steps to install Microsoft Visual Studio Code Editor from the [official visualstudio page](https://code.visualstudio.com/docs/setup/linux)

```
[root@controller ~]# rpm --import https://packages.microsoft.com/keys/microsoft.asc
```

Next execute this script which will create your `/etc/yum.repos.d/vscode.repo` repository file

```
[root@controller ~]# sh -c 'echo -e "[code]\nname=Visual Studio Code\nbaseurl=https://packages.microsoft.com/yumrepos/vscode\nenabled=1\ngpgcheck=1\ngpgkey=https://packages.microsoft.com/keys/microsoft.asc" > /etc/yum.repos.d/vscode.repo'
```
Verify your new repo content

```
[root@controller ~]# cat /etc/yum.repos.d/vscode.repo
[code]
name=Visual Studio Code
baseurl=https://packages.microsoft.com/yumrepos/vscode
enabled=1
gpgcheck=1
gpgkey=https://packages.microsoft.com/keys/microsoft.asc
```
Now you can go ahead and install Visual Studio Code using dnf or yum.

```
[root@controller ~]# dnf install code -y
```

-------------------------------------------
## Access Visual Code Studio

To open the Visual Studio Code Editor, login to the graphical console of your controller node as` ansible `user and execute "`code .`" on the terminal at the home folder or you can using any of the Projects directory

![image](https://user-images.githubusercontent.com/100822553/211266273-efbc39a8-e848-45b1-9082-3015033e7580.png)

The Visual Studio Editor will come up and you can see all the YAML files which we have created are also visible in the LEFT TAB.

----------------------------------------
## Install Ansible Extension
Since we have to work with Ansible we must install the `Ansible Extension/Plugin`. To install this click on "`Extensions`" from the Left Menu and search for "`Ansible`" string. Click on "`install`" to install the respective extension.

![image](https://user-images.githubusercontent.com/100822553/211266421-1783f3bd-644a-409f-b5ce-bae3882e6643.png)

------------------------------------------
## Create playbook using Visual Studio
Now we can create a new file and start by creating a new playbook using the visual editor. Click on `File → New `File which will create a new file. Press `Ctrl+s` to save it with a different name, I will save it as "`playbook_vsc.yaml`"

Now I have created a very simple playbook using the Visual Code Editor. Press `Ctrl+s` to save the playbook before executing.

```
---
 - name: Using Visual Code Editor
   hosts: localhost
   tasks:
     - debug:
         msg: "Hello World"
```
To execute the playbook using Visual Studio press `Ctrl + Shift + P `which will present you a bunch of options for execution. Since we are executing the script on localhost i.e. the controller node, I will use "`Run Ansible Playbook via 'ansible-playbook'`"

![image](https://user-images.githubusercontent.com/100822553/211266838-294600cd-8d6d-4b48-a00c-1e853eeb3fdd.png)

Output from the execution. So our playbook has successfully executed.
![image](https://user-images.githubusercontent.com/100822553/211266872-dd274510-2b34-44c1-9a2f-a0dadf8a850e.png)

--------------------------------
## Further Reading
[Ansible VS Code Extension by Red Hat](https://github.com/ansible/vscode-ansible)
