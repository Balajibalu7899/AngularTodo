# Beginners guide to YAML Syntax in Ansible Playbooks

## Table of Contents

* [What is YAML?](#What-is-YAML?)
* [YAML syntax with file formatting](#YAML-syntax-with-file-formatting)
  * [Key value Pair in YAML File](#Key-value-Pair-in-YAML-File)
  * [Array or Lists in YAML File](#Array-or-Lists-in-YAML-File)
* [Create or Modify .vimrc](#Create-or-Modify-.vimrc)
* [Constructing your ansible playbook](#Constructing-your-ansible-playbook)

-----------------------------
## What is YAML?
* YAML Ain’t Markup Language (YAML) is often called a data serialization language.
* It was intended to be human-readable and organize data into a structured format.
* Programming languages can understand the content of YAML files (which usually have a `.yml` or `.yaml` extension) and map them to built-in data types.
* For example, when you consume a `.yaml` file in your Python script, it will automatically convert the content into either a dictionary `{}` or list `[]`, so you can work and iterate over it.
* All YAML files (regardless of their association with Ansible or not) can `optionally` begin with `---` and end with `....` This is part of the YAML format and indicates the start and end of a document.
* `Lists` in YAML are represented with a `hyphen` followed by a white space. Each `play` is an associative array, a dictionary, or a map in terms of `key-value` pairs.
* Indentations are important. `All members of a list` should be at the `same indentation level`.
* Each play can contain key-value pairs separated by "`:`" to denote hosts, variables, roles, tasks, and so on.

---------------------------------
## YAML syntax with file formatting
There're a few rules to follow while developing YAML files. YAML uses indentation (like Python), which builds the relationship of items with one another:

 
----------------------------------------------
## Key value Pair in YAML File
Below we take data in the simplest form such as key value pair in the YAML format where Key and value are separated by a colon. It is important that you give a whitespace followed y colon differentiating the Key and Value

```
Fruit: Apple
Vegetable: Carrot
Liquid: Water
Meat: Chicken
```

Here Keys are Fruit, Vegetable, Liquid, Meat while the respective Values are Apple, Carrot, Water and Chicken

----------------------------
## Array or Lists in YAML File
Here we list some fruits and vegetables. So Fruits and Vegetables followed by a colon here represent array while all the elements of the array would start with a dash (-) so Orange, Apple and Banana are the elements of Fruits array while Carrot, Cauliflower and Tomato are the elements of Vegetables array

```
Fruits:
- Orange
- Apple
- Banana

Vegetables:
- Carrot
- Cauliflower
- Tomato
```

------------------------------------
## Create or Modify .vimrc
We know that YAML files are based on indentation but one important thing is that in YAML file we should not use TAB instead it is recommended to use space character. So we will update our `.vimrc` file to only allow two spaces when someone hits a TAB button for `yaml FileType`. We will add this in the home folder of ansible user on the controller node where we will be working with our YAML files.

```
[ansible@controller ~]$ cat .vimrc
autocmd FileType yaml setlocal ai ts=2 sw=2 et
```
-------------------------------------------------
## Constructing your ansible playbook

* A playbook is based on YAML file syntax which can contain one or more than one play
* A play is a combination of hosts and tasks.
* A task is nothing but a call or operation, which applies on group of hosts.
* 
Here I have tried to highlight the structure of a playbook:
![image](https://user-images.githubusercontent.com/100822553/211269620-00f3ed83-6e82-47f9-bd48-3a191332cccb.png)

* This is a very simple playbook just to give you an idea of the structure.
* The very first line is the place where we put --- to mark the starting of the playbook
* Next we can either use name to assign a name of the PLAY or you can use hosts. But the second line should start with `[space][dash][space]` followed by the Key which is name with a value "`PLAY-1`"
* Next you can provide the list of hosts and bunch of other options which we will explore through the course of this tutorial
* Then we mention the tasks and alternatively we can assign a name to the task. This will again act as another List with a Key Value pair.
* Under the tasks the first thing we define is "`module`" which will actually perform the task
* Under the module you have to provide the argument lists for the respective module. In this example I have chosen debug module which will print a message on the console.
* I have created two TASKS in PLAY-1 and single TASK in PLAy-2 to give you a rough idea of the playbook structure

