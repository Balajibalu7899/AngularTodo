# Working with managed nodes with password (not passphrase)

In all the examples till now we have used password less communication by setting up a `passphrase with no password`. So that the `controller` is able to communicate with the managed nodes without prompting for any password.

But this is again not a strict requirement (although recommended). We can also use password based communication between controller and managed nodes. To demonstrate this example I have removed `authorized_keys` entry for` controller` node on `server3` so now password less communication won't work for `server3`.

I have updated my `/etc/hosts` on all the nodes with the details of `server3` which is created using the AMI Image of one of our managed nodes.

```
[ansible@controller ~]$ cat /etc/hosts
127.0.0.1   localhost localhost.localdomain localhost4 localhost4.localdomain4
::1         localhost localhost.localdomain localhost6 localhost6.localdomain6
172.31.7.253    controller      controller.example.com
172.31.4.189    server1         server1.example.com
172.31.23.18    server2         server2.example.com
172.31.14.46    server3         server3.example.com
```

Next we will update our `inventory` to also include this host

```
[ansible@controller ~]$ head -n 3 /etc/ansible/hosts
server1
server2
server3
```

Now if I try to do a plain SSH from controller to `server3`, it should prompt me for password:

```
[ansible@controller ~]$ ssh server3
ansible@server3's password:
Activate the web console with: systemctl enable --now cockpit.socket

Last login: Mon Sep 21 07:46:47 2020
[ansible@server3 ~]$
```

So our password less communication is not working any more. Let us now use `ansible` to `ping` to this managed node:

```
[ansible@controller ~]$ ansible server3 -m ping
server3 | UNREACHABLE! => {
    "changed": false,
    "msg": "Failed to connect to the host via ssh: ansible@server3: Permission denied (publickey,gssapi-keyex,gssapi-with-mic,password).",
    "unreachable": true
}
```

So the ansible has failed because `by default ansible will not prompt for any password` so we must supply `--ask-pass` or `-k` to make ansible prompt for the password.

```
[ansible@controller ~]$ ansible server3 -m ping --ask-pass
SSH password:
server3 | SUCCESS => {
    "ansible_facts": {
        "discovered_interpreter_python": "/usr/libexec/platform-python"
    },
    "changed": false,
    "ping": "pong"
}
```

Now you can execute any ad-hoc command or playbook using ansible with `--ask-pass` without the need for passphrase.

